This is my doodle jump game, built from using cmu_112_graphics and python. It is
based on the famous mobile game doodle jump.  


Citations:

I got the pictures/sprites from online:
https://www.spriters-resource.com/mobile/doodlejump/
https://www.vg-resource.com/thread-21558.html
https://www.pinterest.com/pin/44191640069279768/
